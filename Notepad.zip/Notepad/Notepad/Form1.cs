﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Notepad
{
    public partial class Notepad : Form
    {
        public Notepad()
        {
            InitializeComponent();
            
        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
            
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
          
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFileDialog1.FileName = "";
            openFileDialog1.Filter = "Text File | *.txt";

            if (openFileDialog1.ShowDialog()==DialogResult.OK)
            {
                
                StreamReader sr = new StreamReader(openFileDialog1.FileName);

                Task<string> str = sr.ReadToEndAsync();
                txt.Text = str.Result;
                sr.Close();
            }
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            About form1 = new About();
            form1.Show();
        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Help form1 = new Help();
            form1.Show();
        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //save file dialog code
            saveFileDialog1.FileName = ".txt";

            saveFileDialog1.Filter = "Text File | *.txt";

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {

                StreamWriter sw = new StreamWriter(saveFileDialog1.FileName);
                sw.WriteLine(txt.Text);
                sw.Close();

                // MessageBox.Show("File Saved Succcessfully");

            }
            txt.Text = "";


        }

        private void Notepad_Resize(object sender, EventArgs e)
        {
           // txt.Width = Width;
            // txt.Height = this.Height;
            label1.Text = "(" + this.Height + " x " + this.Width + ")";

        }

        private void Notepad_Load(object sender, EventArgs e)
        {
            
        }
    }
}

