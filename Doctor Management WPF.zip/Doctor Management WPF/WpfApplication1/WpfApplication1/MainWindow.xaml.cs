﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public List<Doctor> docList { get; set; }
        
        
        public MainWindow()
        {
            InitializeComponent();
            

        }

        private void btn_Add_Click(object sender, RoutedEventArgs e)
        {
            Doctor t = new Doctor();
            
            t.doc_name = this.docName.Text;
            t.doc_age = int.Parse(this.docAge.Text);
            t.doc_salary = float.Parse(this.docSal.Text);
            
            docList.Add(t);
            MessageBox.Show("Student added successfully");
            
            docAge.Text = "";
            docName.Text = "";
            docSal.Text = "";
        }

        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            docList = new List<Doctor>();

            Doctor doc1 = new Doctor();
            doc1.doc_name = "Ali";
            doc1.doc_age = 12;
            doc1.doc_salary = 15000;

            Doctor doc2 = new Doctor();
            doc2.doc_name = "Aliya";
            doc2.doc_age = 65;
            doc2.doc_salary = 35000;

            Doctor doc3 = new Doctor();
            doc3.doc_name = "Aliyan";
            doc3.doc_age = 65;
            doc3.doc_salary = 69000;


            docList.Add(doc1);
            docList.Add(doc2);
            docList.Add(doc3);

            
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            DataContext = this;
            ICollectionView views = CollectionViewSource.GetDefaultView(docList);
            views.Refresh();
        }
    }
}
