﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication1
{
    public class Doctor
    {
        public string doc_name { get; set; }
        public int doc_age { get; set; }
        public double doc_salary { get; set; }


        public Doctor(string name, int age, float salary)
        {
            doc_name = name;
            doc_age = age;
            doc_salary = salary;
        }

        public Doctor() { }
    }
}
